#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 00:57:43 2023

@author: heitor
"""
import datetime
from main import *



def ganhos_totais():
    print('Até ao momento, a marina de Vila Moura teve um ganho de',sum(lucro_global),'euros.')
    
    

def aumentar_tarifas(percentagem):
    for categoria_de_cais in Cais:
        info = Cais[categoria_de_cais]
        nova_percentagem = info['Preço diário']+ (info['Preço diário']* (percentagem/100))
        info['Preço diário']= nova_percentagem
        print(f'O novo valor diário para o Cais', categoria_de_cais, 'é', info['Preço diário'],'\n')
        for barco in info['embarcações']:
            preço_diário = info['Preço diário']
            estadia = barco['estadia']
            custo = preço_diário * estadia
            custo = round(custo, 2)
            barco ['Preço a pagar']= custo


def prolongamento(matricula,nova_data):
    for categoria_de_cais, info in Cais.items():
        for barco in info['embarcações']:
            if matricula== barco ['matricula']:
                preço_diário= info['Preço diário']
                estadiaantiga= barco['estadia']
                custoantigo= preço_diário * estadiaantiga
                custoantigo= round(custoantigo,2)
                data_antiga= barco['data_saida']
                barco['data_saida']=nova_data
                entrada_stamp = datetime.datetime.strptime(barco['data_entrada'], "%Y-%m-%d")
                saida_stamp = datetime.datetime.strptime(nova_data, "%Y-%m-%d")
                estadia= saida_stamp - entrada_stamp 
                estadia= estadia.days
                barco['estadia']=estadia
                custo= preço_diário * estadia
                custo= round(custo,2)
                barco['Preço a pagar']= custo
                diferença= custo- custoantigo
                print(f'A estadia da embarcação com matricula {matricula} foi prolongada até {nova_data}. \nO valor a pagar era de: ', custoantigo,'euros e agora é de: ', custo,'euros.\nIrá pagar mais: ', diferença,'euros.')
                while True:
                    resposta = input('Deseja continuar? ')
                    if resposta.lower() == 'sim':
                        print('Estadia prolongada com sucesso')
                        break
                    elif resposta.lower() == 'não':
                        barco['estadia'] = estadiaantiga
                        barco['data_saida'] = data_antiga
                        print('Prolongamento de estadia cancelado')
                        break
                    else:
                        print('Resposta dada não esperada, por favor responda Sim ou Não')
            else:
                print(f'A embarcação com a matricula {matricula} não foi encontrada nesta marina')
