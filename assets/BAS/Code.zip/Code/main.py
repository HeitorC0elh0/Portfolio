#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 22:02:34 2023

@author: heitor
"""


Cais= {
 'A':{'Comprimento': (0, 7.99),
     'Preço diário':10.40,
     'numero de lugares':40,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'B':{'Comprimento': (8, 9.99),
     'Preço diário':15.50,
     'numero de lugares':32,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'C':{'Comprimento':(10, 11.99),
     'Preço diário':19.50,
     'numero de lugares':35,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'D':{'Comprimento':(12.0, 14.99),
     'Preço diário':25.60, 
     'numero de lugares':30,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'E':{'Comprimento':(15, 17.99),
     'Preço diário':50.5,
     'numero de lugares':25,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'F':{'Comprimento': (18, 19.99),
     'Preço diário':62.8,
     'numero de lugares':17,
     'embarcações': [],
     'numero de embarcações atracadas': 0},
'G':{'Comprimento':(20.0, 100000.0 ),
     'Preço diário':80,
     'numero de lugares':7,
     'embarcações': [],
     'numero de embarcações atracadas': 0}}



lucro_global=[]

