#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 22:59:38 2023

@author: heitor
"""

import datetime
from main import Cais

def nova_embarcaçao():

        embarcaçao={}
        embarcaçao['matricula'] = input('Insira a matrícula da embarcação: ')
        embarcaçao['proprietário'] = input('Insira o nome do proprietário da embarcação: ')
        embarcaçao['capitão'] = input('Insira o nome do capitão da embarcação: ')
        embarcaçao['origem'] = input('Insira a origem da embarcação: ')
        embarcaçao['passageiros'] = int(input('Insira o número de passageiros da embarcação: '))
        embarcaçao['comprimento'] = float(input('Insira o tamanho da embarcação: '))
        embarcaçao['data_entrada'] = input('Insira a data de entrada da embarcação (YYYY-MM-DD): ')
        embarcaçao['data_saida'] = input('Insira a data de saída da embarcação (YYYY-MM-DD): ')
        estadia (embarcaçao)
        alocar_embarcação(embarcaçao)
        preço_a_pagar(embarcaçao)
        if embarcaçao['estadia'] >= 10:
            descontos(embarcaçao)


            
        
   
def estadia (embarcaçao):
    entrada= embarcaçao['data_entrada']
    saida= embarcaçao['data_saida']
    entrada_stamp = datetime.datetime.strptime(entrada, "%Y-%m-%d")
    saida_stamp = datetime.datetime.strptime(saida, "%Y-%m-%d")
    saida_stamp = datetime.datetime.strptime(saida, "%Y-%m-%d")
    estadia= saida_stamp - entrada_stamp 
    estadia= estadia.days
    embarcaçao['estadia'] = estadia


def alocar_embarcação(embarcaçao):
    tamanho = embarcaçao['comprimento']
    for categoria_de_cais, info in Cais.items():
        min_tamanho, max_tamanho = info['Comprimento']
        if min_tamanho <= tamanho <= max_tamanho and info['numero de embarcações atracadas'] <= info['numero de lugares']:
            info['embarcações'].append(embarcaçao)
            info['numero de embarcações atracadas'] += 1
            print(f'A embarcação de matrícula {embarcaçao["matricula"]} foi atracada no cais {categoria_de_cais}.')
        elif info['numero de embarcações atracadas'] > info['numero de lugares']:
            print(f'Não foi possível alocar a embarcação {embarcaçao["matricula"]} em nenhum cais. Pois o cais preparado para receber embarcações com dimensões entre {embarcaçao["comprimento"]} já não possui vagas')

def preço_a_pagar(embarcaçao):
    
    for categoria_de_cais, info in Cais.items():
        for barco in info['embarcações']:
            if barco ['matricula'] == embarcaçao['matricula']:
                preço_diário= info['Preço diário']
                estadia= embarcaçao['estadia']
                custo= preço_diário * estadia
                custo= round(custo,2)
                embarcaçao ['Preço a pagar']= custo

def descontos(embarcaçao):
    estadia_minima = [10,20,30]
    percentagem = [0.1,0.2,0.3]
    dias= embarcaçao['estadia']

    for i, minimo in enumerate(estadia_minima):
        if dias > minimo:
            desconto = embarcaçao['Preço a pagar'] * percentagem[i]
            embarcaçao['Preço a pagar'] -= desconto

