#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 00:26:58 2023

@author: heitor
"""
from main import Cais
#nota as duas primeiras funções funcionam apenas quando chamadas com print

def embarcações_na_marina():
    embarcações= []

    for info in Cais.values():
        for barco in info['embarcações']:
            embarcações.append(barco)
    return embarcações



def embarcações_por_cais(nome_cais):
    for categoria_de_cais, info in Cais.items():
        if categoria_de_cais==nome_cais:
            if info['embarcações'] is not None:
                return f'No cais {nome_cais} encontra(m)-se atracada(s)', info['numero de embarcações atracadas'],' embarcação(ões). \n Em seguida encontra(m)-se as informações sobre a(s) mesma(s)', info['embarcações']
            else:
                print('Não existem embarcações neste cais')
            
#print(embarcações_por_cais('D'))


def vagas(nome_cais):
    for categoria_de_cais, info in Cais.items():
        if categoria_de_cais==nome_cais:
            vagas= info['numero de lugares'] - info['numero de embarcações atracadas']
            print(f'O número de vagas disponíveis no cais {nome_cais} é/são: {vagas}')
            break
        
    else:
        print(f'O cais {nome_cais}  não corresponde a nenhum cais existente nesta marina')


#fala aqui coisas

def listagem_saida(saida):
    partidas=[]
    for categoria_de_cais, info in Cais.items():
        for barco in info['embarcações']:
            if saida == barco['data_saida']:
                partidas.append(barco)
                if len(partidas) == 1:
                    print(f'Existe uma embarcação com checkout para {saida}.Aqui estão as informações sobre a mesma: ', partidas)
                else:
                    print(f'Para a data {saida} estão destinadas sairem',len(partidas), 'embarcações. em seguida encontram-se as informações sobre as mesmas: ', partidas)
            elif saida != barco['data_saida'] :
                print('Para a data indicada não estão agendados checkouts')
