#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 00:18:17 2023

@author: heitor
"""
from main import *
def partida(matricula):

    found= False
    for categoria_de_cais, info in Cais.items():
        for barco in info['embarcações']:
            if barco['matricula'] == matricula:
                custo = barco['Preço a pagar']
                custo= round(custo,2)
                lucro_global.append(custo)
                info['embarcações'].remove(barco)
                info['numero de embarcações atracadas'] -= 1
                print('O valor a pagar é', float(custo), 'euros.')
                found = True
                break
        if found:
            break
    else:
        print(f'A embarcação com a {matricula} não foi encontrada nesta marina')
        

