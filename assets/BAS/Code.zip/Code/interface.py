#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 01:24:12 2023

@author: heitor
"""

import tkinter as tk
from tkinter.ttk import *
from PIL import ImageTk, Image


from Botoes import *


def abrir_janela_gestão():
    janela_secundária = tk.Toplevel(root)
    janela_secundária.geometry("400x400")
    button1 = tk.Button(janela_secundária, text="Lista de embarcações atracadas na marina", command=todas_embarcações)
    button1.pack()
    button2 = tk.Button(janela_secundária, text="Lista de embarcações por cais", command=embarcações_Cais)
    button2.pack()
    button3 = tk.Button(janela_secundária, text="Lugares disponiveis por cais", command=lugares_disponiveis)
    button3.pack()
    button4 = tk.Button(janela_secundária, text="Lista de embarcações que partem em determinada data", command=Data_partida)
    button4.pack()

def abrir_janela_outros():
    janela_outros = tk.Toplevel(root)
    janela_outros.geometry("400x400")
    button1 = tk.Button(janela_outros, text="Lucro obtido até ao momento", command=lucro)
    button1.pack()
    button2 = tk.Button(janela_outros, text="Aumentar Tarifas", command=tarifas)
    button2.pack()
    button3 = tk.Button(janela_outros, text="Prolongar estadia ", command=prolongar_estadia)
    button3.pack()


root = tk.Tk()
root.title('Marina de Vila Moura: Software de Gestão')
root.geometry("800x500")
#image = Image.open ('Vilamoura-marina-at-night.jpg')
#image= image.resize((800,500))
#photo_image = ImageTk.PhotoImage(image)
#label = Label(root, image=photo_image)
#label.pack()
button1 = tk.Button(root, text="Checkin", command=checkin)
button1.pack()
button2 = tk.Button(root, text="GESTÃO", command=abrir_janela_gestão)
button2.pack()
button3 = tk.Button(root, text="Checkout", command=checkout)
button3.pack()
button4 = tk.Button(root, text='Outros', command=abrir_janela_outros)
button4.pack()
root.mainloop()
