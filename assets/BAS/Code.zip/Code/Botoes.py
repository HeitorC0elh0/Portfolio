import tkinter as tk
import Gestão
from Checkin import *
from Checkout import *
from Gestão import *
from Outros import *



def checkin():
    nova_embarcaçao()
    print('checkin')


def gestão():
    print("Gestão")

def todas_embarcações():
    print(f'A informação em baixo é referente ás embarcações atracadas na marina de Vila Moura. \n',Gestão.embarcações_na_marina())
    print(todas_embarcações)

def embarcações_Cais():
    nome_cais= input('Indique o Cais que pretende verificar: ')
    print(embarcações_por_cais(nome_cais))
    print(embarcações_Cais)

def lugares_disponiveis():
    nome_cais= input('Indique o Cais que pretende verificar: ')
    vagas(nome_cais)
    print(lugares_disponiveis)

def Data_partida():
    saida= input('indique a data para a qual pretende averiguar as partidas agendadas (Utilize o formato YYYY-MM-DD): ')
    listagem_saida(saida)
    print(Data_partida)

def checkout():
    matricula = input('Indique a matricula da embarcação que pretende fazer checkout:')
    partida(matricula)
    print("checkout")


def lucro():
    ganhos_totais()


def tarifas():
    percentagem= int(input('Indique a nova percentagem a aplicar ao valor diário de cada Cais:'))
    aumentar_tarifas(percentagem)

def prolongar_estadia():
    matricula= input('Indique por favor a matricula da embarcação que deseja alterar a data de checkout')
    nova_data= input('Indique a data para a qual pretende prolongar a estadia da embarcação: ')
    prolongamento(matricula,nova_data)

def embarcações_na_marina():
    print('Embarcações na marina')


